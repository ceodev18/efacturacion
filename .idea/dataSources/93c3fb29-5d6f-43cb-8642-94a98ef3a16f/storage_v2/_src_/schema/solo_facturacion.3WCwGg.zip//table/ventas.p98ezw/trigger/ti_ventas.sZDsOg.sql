create definer = root_lsp@`%` trigger ti_ventas
    after insert
    on ventas
    for each row
BEGIN
declare _idtido int;
declare _idempresa int;
declare _idcliente int;
declare _total float;
declare _fecha date;

set _idtido = new.id_tido;
set _idempresa = new.id_empresa;
set _idcliente = new.id_cliente;
set _fecha = new.fecha;
set _total = new.total;

update documentos_empresas as de 
set de.numero = de.numero + 1 
where de.id_empresa = _idempresa and de.id_tido = _idtido;

update clientes as c 
set c.ultima_venta = _fecha, c.total_venta = c.total_venta + _total
where c.id_cliente = _idcliente;

END;

