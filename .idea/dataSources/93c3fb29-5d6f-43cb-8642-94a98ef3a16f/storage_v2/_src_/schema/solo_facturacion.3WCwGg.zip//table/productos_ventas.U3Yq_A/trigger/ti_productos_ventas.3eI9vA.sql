create definer = root_lsp@`%` trigger ti_productos_ventas
    after insert
    on productos_ventas
    for each row
BEGIN
declare _idproducto int;
declare _fecha date;
declare _idventa int;

set _idproducto = new.id_producto;
set _idventa = new.id_venta;

select v.fecha 
into _fecha
from ventas as v 
inner join productos_ventas as pv on pv.id_venta = v.id_venta 
where pv.id_producto = _idproducto and pv.id_venta = _idventa;

update productos as p 
set p.ultima_salida = _fecha 
where p.id_producto = _idproducto;
END;

