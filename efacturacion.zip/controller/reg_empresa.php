<?php
/*
 * al crear empresa generar su contraseña automaticamente y enviar al correo del usuario
 * solicitar ingresar
 */