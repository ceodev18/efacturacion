<?php

header("Location: contents/index.php");