<div class="jumbotron text-center">
    <h1 class="greenter-title"><a href="https://github.com/giansalex/greenter-sample">@giansalex/greenter-sample</a></h1>
    <p>Ejemplos de envío de comprobantes electrónicos a SUNAT, empleando <a href="https://github.com/giansalex/greenter/">Greenter</a></p>
    <sub>UBL 2.0 - UBL 2.1</sub><br>
</div>
