# Greenter Files

En esta carpeta se almacenará los XML generados y Zip de respuestas (CDR).