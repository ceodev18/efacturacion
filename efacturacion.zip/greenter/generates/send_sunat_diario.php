<?php
/**
 * Created by PhpStorm.
 * User: luis
 * Date: 02/09/19
 * Time: 07:45 PM
 */

date_default_timezone_set('America/Lima');

require '../../class/cl_empresa.php';

$c_empresa = new cl_empresa();
//variables publicas
$url = "http://" . $_SERVER["HTTP_HOST"] . "/clientes/sonomusic/";
$fecha = Date("y-m-d");
//$fecha = '2019-09-25';


//recorrer lista de empresas
$array_empresas = $c_empresa->ver_empresas();
foreach ($array_empresas as $fila) {
    $id_empresa = $fila['id_empresa'];

    //enviar resumen de boletas
    $ruta = $url . "greenter/generates/enviar_factura_xml.php";
    $post = [
        'id_empresa' => $id_empresa,
        'fecha' => $fecha
    ];

    $ch_factura = curl_init();
    curl_setopt($ch_factura, CURLOPT_URL, $ruta);
    curl_setopt($ch_factura, CURLOPT_POST, 1);
    curl_setopt($ch_factura, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($ch_factura, CURLOPT_POSTFIELDS, $post);
    curl_setopt($ch_factura, CURLOPT_RETURNTRANSFER, true);
    $respuesta_factura = curl_exec($ch_factura);
    curl_close($ch_factura);

    echo "<br> respuesta factura . <br>";
    print_r($respuesta_factura);
    echo "<br> ";

    $ruta = $url . "greenter/generates/resumen.php";
    //enviar resumen de facturas
    $ch_resumen = curl_init();
    curl_setopt($ch_resumen, CURLOPT_URL, $ruta);
    curl_setopt($ch_resumen, CURLOPT_POST, 1);
    curl_setopt($ch_resumen, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($ch_resumen, CURLOPT_POSTFIELDS, $post);
    curl_setopt($ch_resumen, CURLOPT_RETURNTRANSFER, true);
    $respuesta_resumen = curl_exec($ch_resumen);
    curl_close($ch_resumen);

    echo "<br> respuesta resumen . <br>";
    print_r($respuesta_resumen);
    echo "<br> ";

    //enviar notificacion de bajas
    $ruta = $url . "greenter/generates/comunicacion-baja.php";
    //enviar resumen de facturas
    $ch_baja= curl_init();
    curl_setopt($ch_baja, CURLOPT_URL, $ruta);
    curl_setopt($ch_baja, CURLOPT_POST, 1);
    curl_setopt($ch_baja, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($ch_baja, CURLOPT_POSTFIELDS, $post);
    curl_setopt($ch_baja, CURLOPT_RETURNTRANSFER, true);
    $respuesta_baja= curl_exec($ch_baja);
    curl_close($ch_baja);

    echo "<br> respuesta comunicacion de baja . <br>";
    print_r($respuesta_baja);
    echo "<br> ";

}