<?php
error_reporting(E_ALL);
ini_set('display_errors', '1');

//ini_set('default_socket_timeout', 600);

use Greenter\Model\Sale\Invoice;
use Greenter\Ws\Services\SunatEndpoints;

require __DIR__ . '/../vendor/autoload.php';

require __DIR__ . '/../../class/cl_venta.php';
require __DIR__ . '/../../class/cl_empresa.php';

$util = Util::getInstance();

$id_empresa = filter_input(INPUT_POST, 'id_empresa');
$fecha = filter_input(INPUT_POST, 'fecha');

if ($id_empresa) {

    $c_empresa = new cl_empresa();
    $c_empresa->setIdEmpresa($id_empresa);
    $c_empresa->obtener_datos();

//parametros de archivos xml
    $url = $_SERVER["HTTP_HOST"];
    $dominio = "http://" . $url . "/clientes/sonomusic/";

    $util->setRucEmpresa($c_empresa->getRuc());
    $see = $util->getSee(SunatEndpoints::FE_PRODUCCION);

    $contar_malas = 0;
    $total_filas = 0;

    $mensaje = "";

    $c_venta = new cl_venta();
//lista de documentos por empresa y fecha
    $resultado = $c_empresa->ver_facturas_empresa_sunat($fecha);
    foreach ($resultado as $fila) {
        $total_filas++;
        $c_venta->setIdAlmacen($fila['id_almacen']);
        $c_venta->setIdVenta($fila['id_ventas']);

        //generar nombres de archivos
        $nombre_archivo = $c_empresa->getRuc() . "-01-" . $fila['serie'] . "-" . $fila['vnumero'];
        $nombre_xml = $dominio . "greenter/files/" . $nombre_archivo . ".xml";
        $archivo_xml = "../files/" . $nombre_archivo . ".xml";
        $mensaje = $mensaje . "archivo a enviar = " . $archivo_xml . "<br>";

        if (file_exists($archivo_xml)) {
            /** Si solo desea enviar un XML ya generado utilice esta función* */
            $res = $see->sendXml(Invoice::class, $nombre_archivo, file_get_contents($archivo_xml));

            if ($res->isSuccess()) {
                //obtener cdr y guardar en json
                $cdr = $res->getCdrResponse();
                $util->writeCdr_XML($nombre_archivo, $res->getCdrZip());
                $mensaje = $mensaje . "<br> archivo recibido por sunat " . $cdr->getDescription() . "<br>";
                $c_venta->actualizar_envio();
            } else {
                $mensaje = $mensaje . "<br> error al recibir el archivo ";
                $contar_malas++;
            }
        } else {
            $mensaje = $mensaje . "<br>  archivo no existe = " . $archivo_xml . "<br>";
            $contar_malas++;
        }
    }

    $mensaje = $mensaje . $contar_malas . " de " . $total_filas;

    echo $mensaje;

    $to = "info@lunasystemsperu.com";
    $subject = "Estado del Envio de Facturas Electronica " . $c_empresa->getRuc() . " del dia: " . $fecha;
    $headers = "MIME-Version: 1.0" . "\r\n";
    $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";

    $message = $mensaje;

    mail($to, $subject, $message, $headers);


}