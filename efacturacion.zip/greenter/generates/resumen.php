<?php

use Greenter\Model\Company\Address;
use Greenter\Model\Company\Company;
use Greenter\Model\Summary\Summary;
use Greenter\Model\Summary\SummaryDetail;
use Greenter\Ws\Services\SunatEndpoints;

require __DIR__ . '/../vendor/autoload.php';

//cargar clases del sistema
require __DIR__ . '/../../class/cl_empresa.php';
require __DIR__ . '/../../class/cl_venta.php';
require __DIR__ . '/../../class/cl_resumen_diario.php';

$id_empresa = filter_input(INPUT_POST, 'id_empresa');
$fecha = filter_input(INPUT_POST, 'fecha');

if ($id_empresa) {

//inicar clases del sistema
    $c_empresa = new cl_empresa();
    $c_empresa->setIdEmpresa($id_empresa);
    $c_empresa->obtener_datos();

    $c_venta = new cl_venta();
    $resultado_empresa = $c_venta->ver_resuemn_boletas($c_empresa->getIdEmpresa(), $fecha);


    $util = Util::getInstance();

    $contar_items = 0;
    $array_items = array();
    foreach ($resultado_empresa as $fila) {
        $contar_items++;
        //tipo cliente
        $doc_cliente = "00000000";
        if (strlen($fila['doc_cliente']) == 8) {
            $tipo_doc = 1;
            $doc_cliente = $fila['doc_cliente'];
        } else {
            $tipo_doc = 0;
        }

        //estado
        $estado = $fila['estado'];
        if ($fila['estado'] == 2) {
            $estado = "1";
        }

        //totales
        $total = $fila['total'];
        $subtotal = $total / 1.18;
        $igv = $total / 1.18 * 0.18;


        $item = new SummaryDetail();
        $item->setTipoDoc($fila['cod_sunat'])
            ->setSerieNro($fila['serie'] . "-" . $fila['numero'])
            ->setEstado($estado)
            ->setClienteTipo($tipo_doc)
            ->setClienteNro($doc_cliente)
            ->setTotal($total)
            ->setMtoOperGravadas($subtotal)
            ->setMtoOperInafectas(0)
            ->setMtoOperExoneradas(0)
            ->setMtoOtrosCargos(0)
            ->setMtoIGV($igv);
        $array_items[] = $item;
    }


    $empresa = new Company();
    $empresa->setRuc($c_empresa->getRuc())
        ->setNombreComercial($c_empresa->getRazonSocial())
        ->setRazonSocial($c_empresa->getRazonSocial())
        ->setAddress((new Address())
            ->setUbigueo($c_empresa->getUbigeo())
            ->setDistrito($c_empresa->getDistrito())
            ->setProvincia($c_empresa->getProvincia())
            ->setDepartamento($c_empresa->getDepartamento())
            ->setUrbanizacion('-')
            ->setCodLocal('0000')
            ->setDireccion($c_empresa->getDireccion()));

    $util->setRucEmpresa($c_empresa->getRuc());

    $sum = new Summary();
    $sum->setFecGeneracion(\DateTime::createFromFormat('Y-m-d', $fecha))
        ->setFecResumen(\DateTime::createFromFormat('Y-m-d', $fecha))
        ->setCorrelativo('001')
        ->setCompany($empresa)
        ->setDetails($array_items);


//variables generales
    $nombre_archivo = $sum->getName();
    $dominio = "http://" . $_SERVER["HTTP_HOST"] . "/clientes/sonomusic/";
    $nombre_xml = $dominio . "/greenter/files/" . $sum->getName() . ".xml";
    $nombre_zip_respuesta = $dominio . "/greenter/files/R-" . $sum->getName() . ".zip";

    if ($contar_items > 0) {
// Envio a SUNAT.
        //echo $util->getRucEmpresa();
        $see = $util->getSee(SunatEndpoints::FE_PRODUCCION);

        $res = $see->send($sum);
        $util->writeXml($sum, $see->getFactory()->getLastXml());

//lenar resumen diario;
        $c_resumen = new cl_resumen_diario();
        $c_resumen->obtener_id();
        $c_resumen->setIdEmpresa($c_empresa->getIdEmpresa());
        $c_resumen->setFecha($fecha);
        $c_resumen->setFechaEnvio(date("Y-m-d h:m:s"));
        $c_resumen->setItems($contar_items);
        $c_resumen->setCorrelativo($nombre_archivo);

        if ($res->isSuccess()) {

            /**@var $res \Greenter\Model\Response\SummaryResult */
            $ticket = $res->getTicket();
            $c_resumen->setTicket($ticket);
            $c_resumen->setEstado(1);
            $descripcion = "";
            $result = $see->getStatus($ticket);
            if ($result->isSuccess()) {
                $cdr = $result->getCdrResponse();
                $util->writeCdr($sum, $result->getCdrZip());

                $descripcion = $cdr->getDescription();

                $c_resumen->setEstado(2);
                $util->showResponse($sum, $cdr);
                $respuesta = $util->showResponse($sum, $cdr);

            } else {
                echo $util->getErrorResponse($result->getError());
                $respuesta = $util->getErrorResponse($result->getError());
                /*$respuesta = array(
                    "success" => false,
                    "resultado" => "ERROR EN EL TICKET"
                );*/
                $c_resumen->setEstado(3);
            }

            $c_resumen->insertar();
/*
            $respuesta = array(
                "success" => true,
                "resultado" => array(
                    "ticket" => $ticket,
                    "nombre_archivo" => $nombre_archivo,
                    "direccion_xml" => $nombre_xml,
                    "direccion_zip_respuesta" => $nombre_zip_respuesta,
                    "descripcion_cdr" => $descripcion
                )
            );
*/
        } else {
            //echo $util->getErrorResponse($res->getError());
            $respuesta = $util->getErrorResponse($res->getError());
            /*-$respuesta = array(
                "success" => false,
                "resultado" => "ERROR AL ENVIAR"
            );*/
        }

        //echo json_encode($respuesta);
    } else {
        $respuesta= "error al enviar no hay items";
       /* $respuesta = array(
            "success" => false,
            "resultado" => "ERROR AL ENVIAR - NO HAY ITEMS"
        );*/
        // echo json_encode($respuesta);
    }

    $to = "info@lunasystemsperu.com";
    $subject = "Estado del Envio de Resumen de Boletas " . $c_empresa->getRuc() . " del dia: " . $fecha;
    $headers = "MIME-Version: 1.0" . "\r\n";
    $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";

    $message = $respuesta;

    mail($to, $subject, $message, $headers);
}