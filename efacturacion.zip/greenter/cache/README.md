# Greenter Cache

Almacena la cache generada por las plantillas de los formatos xml.